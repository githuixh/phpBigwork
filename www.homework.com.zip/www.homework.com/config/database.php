<?php 
return ([
	'host' => '127.0.0.1', //主机地址
	'username' => 'root', //数据库用户名
	'password' => 'root', //数据库密码
	'database' => 'homework', //数据库名
	'port' => '3306',//数据库端口号
	
]);
?>